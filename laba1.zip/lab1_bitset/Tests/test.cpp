#include "../bitset/bitset.h"
#include <gtest/gtest.h>



////////////TestBitsetCreation////////////
TEST(TestBitsetCreation, simple_test1){
    BitArray first;
    //EXPECT(first.size(), 0);
    EXPECT_TRUE(1 == 1);
}

// TEST(TestBitsetCreation, simple_test2){
//     BitArray first(1, 1);
//     //EXPECT(first[31], 1);
//     EXPECT_TRUE(1 == 1);
// }

// ////////////TestBitsetSwap////////////
// TEST(TestBitsetSwap, simple_test1){
//     BitArray first(1, 2);
//     BitArray second(1, 1);
//     first.swap(second);
//     EXPECT_EQ(first[31], 1);
//     EXPECT_EQ(second[30], 1);
// }

// ////////////TestBitsetResize////////////
// TEST(TestBitsetResize, simple_test1){
//     BitArray first(1, 1);
//     first.resize(33, 0);
//     BitArray second(33, 1);
//     EXPECT_TRUE(first == second);
// }

// TEST(TestBitsetResize, simple_test2){
//     BitArray first(33, 1);
//     first.resize(1, 0);
//     BitArray second(1, 0);
//     EXPECT_TRUE(first == second);
// }

// TEST(TestBitsetResize, simple_test3){
//     BitArray first(33, 1);
//     first.resize(1, 0);
//     BitArray second(1, 0);
//     EXPECT_TRUE(first == second);
// }

// ////////////TestBitsetRavno////////////
// TEST(TestBitsetRavno, simple_test1)
// {
//     BitArray first(33, 1);
//     BitArray second = first;
//     EXPECT_TRUE(first == second);
// }

// // ////////////TestBitsetClear////////////
// // TEST(TestBitsetClear, simple_test1)
// // {
// //     BitArray first(33, 1);
// //     first.clear();
// //     EXPECT_ANY_THROW({ int a  = first[0];});
// // }

// ////////////TestBitsetRavno////////////
// TEST(TestBitsetPush_back, simple_test1)
// {
//     BitArray first(33, 1);
//     first.push_back(1);
//     EXPECT_TRUE(first[32] == 1);
// }

// TEST(TestBitsetPush_back, simple_test2)
// {
//     BitArray first(1, 1);
//     first.push_back(1);
//     EXPECT_TRUE(first[32] == 1);
// }

// ////////////TestBitsetOperator////////////
// TEST(TestBitsetOperator, simple_test1)
// {
//     BitArray first(1, 1);
//     first <<= 31;
//     EXPECT_TRUE(first[0] == 1);
// }

// //

// ////////////TestBitsetSet////////////
// TEST(TestBitsetSet, simple_test1)
// {
//     BitArray first(1, 1);
//     first.set();
//     for (int i = 0; i < 32; ++i)
//     {
//         EXPECT_EQ(first[i], 1);
//     }
// }

// //

// ////////////TestBitsetReset////////////
// TEST(TestBitsetReset, simple_test1)
// {
//     BitArray first(1, 1);
//     first.reset();
//     for (int i = 0; i < 32; ++i)
//     {
//         EXPECT_EQ(first[i], 0);
//     }
// }

// ////////////TestBitsetAny////////////
// TEST(TestBitsetAny, simple_test1)
// {
//     BitArray first(1, 1);
//     EXPECT_EQ(first.any(), 1);
// }

// ////////////TestBitsetNone////////////
// TEST(TestBitsetNone, simple_test1)
// {
//     BitArray first(1, 0);
//     EXPECT_EQ(first.none(), 1);
// }

// ////////////TestBitsetCount////////////
// TEST(TestBitsetCount, simple_test1)
// {
//     BitArray first(1, 1);
//     EXPECT_EQ(first.count(), 1);
// }


 int main(int argc, char** argv){
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
 }