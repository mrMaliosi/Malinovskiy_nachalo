#pragma once
#include <string>
#include <iostream>
#include <memory>
#define VALUE_BITS (CHAR_BIT * sizeof(bitword))
class BitArray
{
	typedef unsigned long bitword;
private:
	std::unique_ptr<bitword[]> bits_;
	int size_;
	int maxSize_;
	int bytes_;
public:
	BitArray()
	{
		this->bits_ = std::make_unique<bitword[]>(1);
   	 	this->maxSize_ = 1;
    	this->size_ = 0;
    	this->bytes_ = 1;
	}
	~BitArray()
	{
		std::cout << "1" << std::endl;
	}
	bool operator==(const BitArray & b);
	bool operator!=(const BitArray & b);

	//Конструирует массив, хранящий заданное количество бит.
  	//Первые sizeof(long) бит можно инициализровать с помощью параметра value.
	explicit BitArray(int num_bits, unsigned long value);
	BitArray(const BitArray& b);


	//Обменивает значения двух битовых массивов.
	void swap(BitArray& b);

	BitArray& operator=(const BitArray& b)
	{
		if (this->maxSize_ >= b.maxSize_)
		{
			int l = b.size_;
			for (int i = 0; i < l; ++i)
			{
				this->bits_[i] = b.bits_[i]; 
			}
			
		}
		else
		{
			int l = b.size_;
			this->bits_.reset();
			this->bits_ = std::make_unique<bitword[]>(l);
			this->maxSize_ = l;
			this->size_ = l;
			for(int i = 0; i < l; ++i)
			{
				this->bits_[i] = b.bits_[i];
			}
		}
		return *this;
	}


	//Изменяет размер массива. В случае расширения, новые элементы 
  	//инициализируются значением value.
	void resize(int num_bits, bool value);
	//Очищает массив.
	void clear();
	//Добавляет новый бит в конец массива. В случае необходимости 
  	//происходит перераспределение памяти.
	void push_back(bool bit);


	//Битовые операции над массивами.
  	//Работают только на массивах одинакового размера.
  	//Обоснование реакции на параметр неверного размера входит в задачу!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!	
	BitArray& operator&=(const BitArray& b)
	{
		if (this->size_ == b.size_)
		{
			int l = b.size_;
			for (int i = 0; i < l; ++i)
			{
				this->bits_[i] &= b.bits_[i]; 
			}
			return *this;
		}
		else
		{

		}
	}
	BitArray& operator|=(const BitArray& b)
	{
		if (this->size_ == b.size_)
		{
			int l = b.size_;
			for (int i = 0; i < l; ++i)
			{
				this->bits_[i] |= b.bits_[i]; 
			}
			return *this;
		}
		else
		{

		}
	}
	BitArray& operator^=(const BitArray& b)
	{
		if (this->size_ == b.size_)
		{
			int l = b.size_;
			for (int i = 0; i < l; ++i)
			{
				this->bits_[i] ^= b.bits_[i]; 
			}
			return *this;
		}
		else
		{

		}
	}

	//Битовый сдвиг с заполнением нулями.
	BitArray& operator<<=(int n)
	{
		std::unique_ptr<bitword[]>p = std::make_unique<bitword[]>(this->bytes_);
		bitword byte = 0;
		int count = 0;
		for (int i = n; i < this->size_; ++i)
		{
			int k = n / VALUE_BITS;
			int j = n % VALUE_BITS;
			int bit = (1 << (VALUE_BITS - 1 - j))&this->bits_[k];
			p[count / VALUE_BITS] <<= 1;
			p[count / VALUE_BITS] |= 1;
			++count;
		}
		this->bits_ = move(p);
		return *this;
	}
	BitArray& operator>>=(int n);
	BitArray operator<<(int n) const;
	BitArray operator>>(int n) const;


	//Устанавливает бит с индексом n в значение val.
	BitArray& set(int n, bool val);
	//Заполняет массив истиной.
	BitArray& set();

	//Устанавливает бит с индексом n в значение false.
  	BitArray& reset(int n);
  	//Заполняет массив ложью.
  	BitArray& reset();

  	//true, если массив содержит истинный бит.
  	bool any() const;
  	//true, если все биты массива ложны.
  	bool none() const;
  	//Битовая инверсия
  	BitArray operator~() const
	{
		for (int i = 0; i < this->bytes_; ++i)
		{
			this->bits_[i] = ~this->bits_[i];
		}
		return *this;
	}
  	//Подсчитывает количество единичных бит.
  	int count() const;


  	//Возвращает значение бита по индексу i.
  	bool operator[](int i) const
	{
		int k = i / VALUE_BITS;
		int j = i % VALUE_BITS;
		int b = 1 << (VALUE_BITS - 1 - j);
		return b & this->bits_[k] ? 1 : 0;
	}

  	int size() const;
  	bool empty() const;
  
  	//Возвращает строковое представление массива.
  	std::string to_string() const;

};


BitArray operator&(const BitArray& b1, const BitArray& b2);
BitArray operator|(const BitArray& b1, const BitArray& b2);
BitArray operator^(const BitArray& b1, const BitArray& b2);

